NDK=/home/blueberry/developer/Sdk/ndk-bundle
$NDK/ndk-build NDK_APPLICATION_MK=./jni/Application.mk NDK_PROJECT_PATH=./
